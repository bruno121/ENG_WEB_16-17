class Client2
    require "socket"
    class Client
      def initialize( server )
        @server = server
        @request = nil
        @response = nil
        listen
        sends
        @request.join
        @response.join

      end


      def listen
        @response = Thread.new do
          loop {
            msg = @server.gets.chomp
            puts "#{msg}"
          }
        end
      end

      def sends
        id=1
        @server.puts ("temperatura")
        @request = Thread.new do
          loop {
            r=rand(0..30)
            @server.puts("M,#{id},#{r},#{Time.now.ctime},temperatura")
            sleep(5)
          }
        end
      end
    end

    server = TCPSocket.open( "127.0.0.1", 3000 )
    Client.new( server )
  end
